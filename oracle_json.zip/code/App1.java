import oracle.soda.OracleCollection;
import oracle.soda.OracleDatabase;
import oracle.soda.OracleDocument;
import oracle.soda.rdbms.OracleRDBMSClient;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class App1 {
	public static void main(String[] args) throws Throwable {
		try (Connection connection = DriverManager.getConnection(
				String.format("jdbc:oracle:thin:@%sTNS_ADMIN=/home/loic_lefev",
						System.getenv("ORACLEDB_CONNECTION_STRING")),
				System.getenv("ORACLEDB_USER"),
				System.getenv("ORACLEDB_PASSWORD"))) {
			connection.setAutoCommit(false);

			Properties props = new Properties();
            props.put("oracle.soda.sharedMetadataCache", "true");

			OracleDatabase soda = new OracleRDBMSClient(props).getDatabase(connection);
			OracleCollection collection = soda.openCollection("purchase_orders");

			String indexSpec = """
					{ "name": "REQUESTOR_IDX",
					  "fields": [{"path": "requestor",
					              "datatype": "string",
					              "order": "asc" }] }""";
			collection.admin().createIndex(soda.createDocumentFromString(indexSpec));

			OracleDocument doc = collection.insertAndGet(soda.createDocumentFromString("""
					{ "requestor": "Loïc Lefèvre", "address": { "city": "Tours" } }"""));
			System.out.printf("Document key/Id is: %s", doc.getKey()).println();

			doc = collection.find().key(doc.getLastModified()).getOne();  // a SODA document
			System.out.printf("JSON document as string: %s", doc.getContentAsString()).println(); // a String
		}
	}
}
