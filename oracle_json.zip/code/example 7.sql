-- Création d'une table avec type natif JSON (21c+)
create table jsontab (a number, doc JSON);

-- Insertion de 2 documents contenant des tableaux d'entiers
insert into jsontab VALUES (1, '{"credit_score": [710, 720, 710, 730]}');
insert into jsontab VALUES (2, '{"credit_score": [750, 730, 750, 750]}');  

-- Création d'un Multi-Value Index (MVI)
create MULTIVALUE index jsontab_idx
on jsontab t ( t.doc.credit_score.number() ); 

-- Comptage du nombre de documents contenant au moins une fois la valeur 750
-- dans le tableau optionnel credit_score.
select count(*)
  from jsontab t
 where JSON_EXISTS(t.doc, '$.credit_score?(@ == 750)');
