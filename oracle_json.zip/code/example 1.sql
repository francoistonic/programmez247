-- Type natif JSON à partir de la version 21c
create table emp ( data JSON ); 
-- Type alternatif BLOB avec contrainte IS JSON à partir de la version 12c
--
-- create table emp ( 
--    data BLOB check (data IS JSON) 
-- ) 
-- lob(data) store as (cache);
insert into emp (data) values 
( '{"name": "Loïc", 
    "job": "PM", 
    "salary": 20000, 
    "created": "2021-04-17T10:05:00.000Z", 
    "email": "loic@oracle.com",
    "phones": [ {"type": "home", "num": "+33123456789"},
                         {"type": "mobile", "num": "+33678901234"}
              ]
   }' );

-- Projection des valeurs JSON en colonnes relationnelles : "dot notation"
select e.data.name.string(),
       e.data.job.string(),
       e.data.salary.number(),
       e.data.created.timestamp(),
       e.data.email.string()
  from emp e;
