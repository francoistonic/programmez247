'use strict';
const oracledb = require('oracledb');
oracledb.autoCommit = true; // OK for simple operations

async function run() {
    let connection, collection;

    try {
        connection = await oracledb.getConnection({
            user: process.env.ORACLEDB_USER || "USERNAME",
            password: process.env.ORACLEDB_PASSWORD || "PASSWORD",
            connectString: process.env.ORACLEDB_CONNECTION_STRING || "CONNECTION_STRING"
        });

        console.log("Oracle client version: ", oracledb.oracleClientVersion);
        console.log("Oracle database version: ", connection.oracleServerVersion);

        const soda = connection.getSodaDatabase(); // Create the parent object for SODA

        // sqlType: "BLOB" for 19c, "JSON" for 21c
        const metadata = { keyColumn: { name: "ID" },
                           contentColumn: { name: "JSON_DOCUMENT", sqlType: "JSON" },
                           versionColumn: { name: "VERSION", method: "UUID" },
                           lastModifiedColumn: { name: "LAST_MODIFIED" },
                           creationTimeColumn: { name: "CREATED_ON" }
                         };

        collection = await soda.createCollection("purchase_orders", metadata);

        const indexSpec = { name: "REQUESTOR_IDX",
                            fields: [{
                                path: "requestor",
                                datatype: "string",
                                order: "asc"
                            }]
                        };

        try { await collection.createIndex(indexSpec); } catch (err) { console.error(err); }

        // insert a document
        let doc = await collection.insertOneAndGet({ requestor: "Loïc Lefèvre", 
                                                     address: { city: "Tours" } });
        console.log("Document key/Id is: ", doc.key);

        doc = await collection.find().key(doc.key).getOne();                // a SODA document
        console.log("JSON document: ", doc.getContent());                   // a JSON document
        console.log("JSON document as string: ", doc.getContentAsString()); // a string
    } 
    catch (err) { console.error(err); } 
    finally { if (connection) { try { await connection.close(); } 
                                catch (err) { console.error(err); } } }
}

run();