-- Projection des valeurs JSON en colonnes relationnelles avec valeurs imbriquées
-- Notation simplifiée (21c+)
select e.*
  from emp nested data columns (
            name,
            job,
            salary,
            nested phones[*] columns (
                type,
                num
            )
        ) e;
