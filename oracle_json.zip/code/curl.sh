$ curl -s -X POST -u JSONUSER:$PASSWORD -H "Content-Type: application/sql" https://<url prefix>/ords/jsonuser/_/sql --data-binary "select * from invoice" | jq

{
  "env": {
    "defaultTimeZone": "UTC"
  },
  "items": [
    {
      "statementId": 1,
      "statementType": "query",
      "statementPos": {
        "startLine": 1,
        "endLine": 2
      },
      "statementText": "select * from invoice",
      "resultSet": {
        "metadata": [
          {
            "columnName": "ID",
            "jsonColumnName": "id",
            "columnTypeName": "VARCHAR2",
            "precision": 255,
            "scale": 0,
            "isNullable": 0
          },
          {
            "columnName": "CREATED_ON",
            "jsonColumnName": "created_on",
            "columnTypeName": "TIMESTAMP",
            "precision": 0,
            "scale": 6,
            "isNullable": 0
          },
          {
            "columnName": "JSON_DOCUMENT",
            "jsonColumnName": "json_document",
            "columnTypeName": "JSON",
            "precision": -1,
            "scale": 0,
            "isNullable": 1
          }
        ],
        "items": [
          {
            "id": "F92F8DB4202544B58BF0ADC0DE447E80",
            "created_on": "2021-04-27T14:40:58.169Z",
            "json_document": {
              "purchaseOrderId": "F92F8DB4202544B58BF0ADC0DE447E80",
              "totalPrice": 25.52,
              "totalPriceWithVAT": 30.624,
              "country": "France"
            }
          }
        ],
        "hasMore": false,
        "limit": 10000,
        "offset": 0,
        "count": 1
      },
      "response": [],
      "result": 0
    }
  ]
}

